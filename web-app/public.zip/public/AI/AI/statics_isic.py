import os

data_dir="/media/milton/ssd1/research/competitions/ISIC_2018_data/data"
class_names=["MEL","NV","BCC","AKIEC","BKL","DF","VASC"]
positive_label = [1, 0, 0]
negative_label = [0, 1, 0]
neutral_label = [0, 0, 1]